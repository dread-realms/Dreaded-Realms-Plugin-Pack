Sean Entrance Resource Pack
===========================

1. Copy your OGG file here:
   assets/dreadedrealms/sounds/pokesean.ogg

2. Zip the contents of this folder (pack.mcmeta must be at the root of the zip)
   and put the zip in .minecraft/resourcepacks/

3. Enable the pack in Minecraft: Options → Resource Packs

4. Sound key for the plugin config: dreadedrealms:pokesean
   (Use this in Dreaded-Realms-Sean-Entrance config when the plugin supports custom sound keys.)
